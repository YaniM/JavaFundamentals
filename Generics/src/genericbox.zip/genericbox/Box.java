package genericbox;

import java.lang.reflect.Array;

public class Box<T> {
    private T item;
    private Class<T> clazz;

    public Box(Class<T> clazz, T item) {
        this.item = item;
        this.clazz = clazz;
    }

    @Override
    public String toString() {
        return  this.clazz.getName()+ ": " + this.item;
    }
}
